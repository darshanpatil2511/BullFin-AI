export default function Navbar() {
    return (
      <nav className="p-4 bg-white shadow-md">
        <span className="text-xl font-bold">BullFin.AI</span>
      </nav>
    );
  }